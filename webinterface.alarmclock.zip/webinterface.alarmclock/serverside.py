import xbmc, xbmcaddon
import time, datetime
import glob

addon = xbmcaddon.Addon('screensaver.alarmclock')
active = False
 
##
# get argv when called from JsonRPC
#
# parse an alarm time and update settings for the alarmclock
